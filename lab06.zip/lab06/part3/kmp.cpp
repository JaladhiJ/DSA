#include <iostream>
#include <cstring>

// Fills lps[] for given pattern pat[0..M-1]
void computeLPSArray(char* pat, int M, int* lps)
{

}

// Prints occurrences of txt[] in pat[]
void KMPSearch(char* pat, char* txt)
{
	// printf("Found pattern at index %d \n", index_where_found);
}
